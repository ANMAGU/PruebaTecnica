package com.ibarra.angela.pruebatecnica.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ibarra.angela.pruebatecnica.R;
import com.ibarra.angela.pruebatecnica.modelos.Pelicula;

import java.util.List;

public class PeliculasRecycler extends  RecyclerView.Adapter<PeliculasRecycler.PeliculaViewHolder> {
    List<Pelicula> pelis;
    Context context;

    public interface OnItemClick {
        void itemClick(Pelicula peli, int position);
    }
    private OnItemClick listener ;
    public PeliculasRecycler(List<Pelicula> pelis, Context context, OnItemClick listener) {
        this.pelis = pelis;
        this.context = context;
        this.listener = listener;
    }
    public static class PeliculaViewHolder extends RecyclerView.ViewHolder {
        TextView titulo,fecha;
        public PeliculaViewHolder(@NonNull View itemView) {
            super(itemView);
            titulo = (TextView) itemView.findViewById(R.id.titulo);
            fecha = (TextView) itemView.findViewById(R.id.fecha);
        }
        public void bind (Pelicula pelicula, int position ,  OnItemClick listener) {
            titulo.setText(pelicula.getTitle());
            fecha.setText(pelicula.getRelease_date());
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
    @NonNull
    @Override
    public PeliculaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        PeliculaViewHolder invitacionesViewHolder = new PeliculaViewHolder(view);
        return invitacionesViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull PeliculaViewHolder peliculaViewHolder, int i) {
        peliculaViewHolder.bind(pelis.get(i),i,listener);
    }

    @Override
    public int getItemCount() {
        return pelis.size();
    }
}
