package com.ibarra.angela.pruebatecnica;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.ibarra.angela.pruebatecnica.adapter.PeliculasRecycler;
import com.ibarra.angela.pruebatecnica.modelos.Pelicula;
import com.ibarra.angela.pruebatecnica.services.BuscarPeliculas;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
public  String URLAPI = "";
public  String APIKEY = "810bc4d1";
public  String parametrobusqueda = "netflix";
    List<Pelicula> peliculas;
    RecyclerView recycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        peliculas = new ArrayList<Pelicula>();
        recycler = (RecyclerView) findViewById(R.id.recycler);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recycler.setLayoutManager(linearLayoutManager);
        buscarTopPeliculas();


    }

    public void buscarTopPeliculas() {
        URLAPI = "https://api.themoviedb.org/3/discover/movie?certification_country=US&certification.lte=G&sort_by=popularity.desc&api_key=23e55efed5cef4e8977a6d17c4cbcbee";
        BuscarPeliculas buscarPeliculas = (BuscarPeliculas) new BuscarPeliculas(new BuscarPeliculas.AsyncResponse(){

            @Override
            public void processFinish(String output) {
                if (output != null) {
                    Log.e("logg", "Respuesta del servicio: " + output.toString());
                    try {
                        JSONObject res = new JSONObject(output);
                        if (!res.isNull("results")) {
                            JSONArray pelis = res.getJSONArray("results");
                            if (pelis.length() > 0) {
                                for (int i = 0; i < pelis.length(); i++) {
                                    JSONObject peli = pelis.getJSONObject(i);
                                    Pelicula pelicula = new Pelicula();
                                    pelicula.setTitle(peli.getString("title"));
                                    pelicula.setPoster_path(peli.getString("poster_path"));
                                    pelicula.setRelease_date(peli.getString("release_date"));
                                    pelicula.setVote_average(peli.getString("vote_average"));
                                    peliculas.add(pelicula);
                                }
                                setPelis();
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).execute(URLAPI);

    }
    public void setPelis(){
        PeliculasRecycler peliculasRecycler = new PeliculasRecycler(peliculas, MainActivity.this, new PeliculasRecycler.OnItemClick() {
            @Override
            public void itemClick(Pelicula peli, int position) {

            }
        });
        recycler.setAdapter(peliculasRecycler);
    }
}
